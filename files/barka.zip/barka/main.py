import time
from datetime import datetime
from playsound import playsound
while(1 == 1):
    czas = datetime.now()
    czast = czas.strftime("%H:%M:%S")
    if(czast == "21:37:00"):
           playsound('barka.mp3')



